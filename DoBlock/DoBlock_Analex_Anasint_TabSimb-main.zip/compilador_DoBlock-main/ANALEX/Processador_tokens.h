#ifndef PROCESSADOR_TOKENS_H
#define PROCESSADOR_TOKENS_H

#include <stdio.h>

void processador_tokens(FILE *fd);

#endif
